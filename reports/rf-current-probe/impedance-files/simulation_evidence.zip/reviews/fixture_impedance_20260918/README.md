# 교정 PCB A02 임피던스 사전 검토

2026-09-18 · **SIMULATED / 발주 보류**

중앙 신호선이 코어 안을 통과하고 양쪽 GND가 코어 밖으로 돌아오는 원칙은 맞다. 그러나 기존 DRC 결과는 RF 정합 근거가 아니다. 실제 채워진 PCB 동박을 읽어 중앙 단면의 준정적 해석을 수행했다.

- 실제 치수: SIG 폭 6.8 mm, 신호–귀환 공기 간격 47.9 mm, GND 레일 폭 20.2 mm. 양면 동일. 중앙 FR4 8 × 1.6 mm.
- 가정: FR4 εr=4.3, 무한히 이어지는 단면, 무손실·무코어. 실제 제조사 적층 유전율은 확정하지 않았다.
- 0.30 / 0.15 / 0.075 mm 격자: 241.206 / 241.450 / 241.650 Ω.
- 경계 영역 500→1000 mm 변화: 0.01% 미만. 공기 중 이상 CPW 해석식 최세밀 기준 모델 오차 0.49%.
- 검증은 정전용량의 전하/에너지 일치, 격자·영역 수렴, 해석식 기준 모델 대조다. 실측·3D RF 시험이 아니다.

**241.65 Ω는 실제 PCB 전체의 입력 임피던스가 아니다.** 창 길이 33.75 mm가 귀환 간격보다 짧다. 양끝 전이·SMA·비아·코어·권선·주변 물체가 만드는 3D 효과가 빠졌다. `results.json`의 균일 구간 회로 및 5.3 pF 후보는 예시이며 보정값·발주품으로 사용하지 않는다.

## 결정

1. A02는 그대로 주문하지 않는다. BOM E03 및 구매서에 보류를 표시했다.
2. 코어 밖 귀환을 유지한다. 중앙 아래 GND를 넣어 교정 전류를 상쇄시키는 변경은 금지한다.
3. 전체 지그와 코어 안 전류 기준면을 모델링한 뒤 무실장/정합 소자 후보를 비교한다. 이후 새 리비전 Gerber와 부품을 확정한다.
4. 실물은 SOLT 기준면·50 Ω 종단을 정의하고 빈 지그 / 프로브 부착 상태의 S11/S21/S12/S22 원본을 100 kHz–500 MHz에 저장한다. 단순 `50×S21`, `1−S11`로 자동 보정하지 않는다.

이번 검토에서는 CAD, PCB, Gerber, JLC 주문을 변경하지 않았다.

## 재현과 원본

- `analysis/extract_fixture_cross_section.py`: KiCad 10.0.0 Python 3.11. 채워진 동박의 중심 스캔.
- `analysis/fixture_impedance_20260918.py`: 프로젝트 .venv Python, NumPy/SciPy. 버전은 `runtime.json`.
- `cad_cross_section.json`: 실제 치수·원본 PCB SHA256.
- `results.json`: 모델·격자·수치·분류·해석 소스 SHA256.
- `potential_field.npz`: 최세밀 모델 전위·좌표·도체 마스크 원본.

```powershell
& 'C:/Program Files/KiCad/10.0/bin/python.exe' analysis/extract_fixture_cross_section.py
& ./.venv/Scripts/python.exe analysis/fixture_impedance_20260918.py
```

공식 근거: [Qucs Technical Papers 12장 CPW](https://qucs.sourceforge.net/docs/technical/technical.pdf), [Tekbox 교정지그](https://www.tekbox.com/product/TBCPx_Calibrators_Manual.pdf), [JLC 일반 임피던스 제어](https://jlcpcb.com/impedance).
