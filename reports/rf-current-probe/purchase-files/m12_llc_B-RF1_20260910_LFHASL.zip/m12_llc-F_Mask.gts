G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*
G04 #@! TF.CreationDate,2026-09-10T18:53:12+09:00*
G04 #@! TF.ProjectId,m12_llc,6d31325f-6c6c-4632-9e6b-696361645f70,B-RF1*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-09-10 18:53:12*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,3.000000*%
%ADD11RoundRect,0.450000X-0.365022X0.521305X-0.521305X-0.365022X0.365022X-0.521305X0.521305X0.365022X0*%
%ADD12C,1.800000*%
%ADD13C,3.250000*%
%ADD14C,1.300000*%
%ADD15C,2.800000*%
G04 APERTURE END LIST*
D10*
X35000000Y-28000000D03*
D11*
X45988777Y-18124505D03*
D12*
X45468612Y-21074510D03*
X47150203Y-22615405D03*
X49416354Y-22357210D03*
X50708221Y-20477532D03*
X50137151Y-18269369D03*
X48095974Y-17251675D03*
X48000000Y-20000000D03*
D13*
X12000000Y-25715000D03*
X12000000Y-14285000D03*
D14*
X17000000Y-16390000D03*
X19030000Y-17410000D03*
X17000000Y-18430000D03*
X19030000Y-19450000D03*
X17000000Y-20470000D03*
X19030000Y-21490000D03*
X17000000Y-22510000D03*
X19030000Y-23530000D03*
D15*
X8540000Y-27940000D03*
X8540000Y-12060000D03*
M02*
