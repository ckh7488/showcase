G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*
G04 #@! TF.CreationDate,2026-09-10T14:35:05+09:00*
G04 #@! TF.ProjectId,molex_slipring,6d6f6c65-785f-4736-9c69-7072696e672e,A-DRAFT*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-09-10 14:35:05*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,3.250000*%
%ADD11C,1.300000*%
%ADD12C,2.800000*%
%ADD13R,2.150000X1.300000*%
%ADD14RoundRect,0.100000X0.500000X-0.300000X0.500000X0.300000X-0.500000X0.300000X-0.500000X-0.300000X0*%
G04 APERTURE END LIST*
D10*
X12000000Y-25715000D03*
X12000000Y-14285000D03*
D11*
X17000000Y-16390000D03*
X19030000Y-17410000D03*
X17000000Y-18430000D03*
X19030000Y-19450000D03*
X17000000Y-20470000D03*
X19030000Y-21490000D03*
X17000000Y-22510000D03*
X19030000Y-23530000D03*
D12*
X8540000Y-27940000D03*
X8540000Y-12060000D03*
D13*
X49430000Y-23095000D03*
X49430000Y-14305000D03*
D14*
X47050000Y-16200000D03*
X47050000Y-17450000D03*
X47050000Y-18700000D03*
X47050000Y-19950000D03*
X47050000Y-21200000D03*
M02*
