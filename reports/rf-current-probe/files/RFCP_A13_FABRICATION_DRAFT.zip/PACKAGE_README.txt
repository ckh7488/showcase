RFCP A13/C07 · DRAFT — NOT FOR FABRICATION
STL 10종/15개, Head PCB A03, Fixture PCB A02, 조립 참고 STEP.
IMPORTANT: Fixture PCB A02 is ON HOLD. 50-ohm matching has NOT been established. Do NOT order this revision. See impedance-review.html.
교정 PCB A02는 과거 참고 파일입니다. 정합 검증과 새 리비전 확정 전 발주하지 않습니다.
BOM과 조립절차서의 미선정/미해결 항목 확인 전 발주 승인본이 아닙니다.
STL별 수량은 bom.html, 조립 순서는 assembly-guide.html을 참조합니다.
