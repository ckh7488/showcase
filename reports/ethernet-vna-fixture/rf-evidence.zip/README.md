# 共通 Ethernet balun PCB / openEMS evidence

Raw solver traces: 2026-09-29. Frequency-domain extraction: 2026-11-13.

`python -m pip install numpy` then `python reproduce.py` reproduces the two B-pair responses from the saved odd/even terminal waveforms. Results go to `combined/`.

The models cover the PCB copper between RJ45 and the differential balun pads. They use lossless nominal FR-4, PEC copper, sixteen nominal 50-ohm terminals, 100-ohm differential and 25-ohm common-mode normalization. Geometry and vias come from the saved CAD. `com_old` is the differential routing retained in the B-RJ2 manufacturing source; `com_front` is the alternative front-mounted reroute.

`common-board-rf.csv` contains 1–150 MHz values at 1 MHz intervals. Coupling is the largest differential NEXT/FEXT magnitude among the six B-to-A/C/D paths at each frequency.

Source and packaged SHA-256 receipts are in `provenance.json`. Four raw run metadata files have filesystem paths reduced to basenames for portability. NPZ arrays are unchanged. Window diagnostics and terminal residuals are in the extracted JSON reports.
