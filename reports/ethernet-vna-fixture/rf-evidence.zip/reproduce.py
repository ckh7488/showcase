from pathlib import Path
import analyze
analyze.O = Path(__file__).resolve().parent
for case in ('com_old', 'com_front'):
    result = analyze.extract(f'{case}-B-odd-base-v2', f'{case}-B-even-base-v2', f'{case}-B-base-v2')
    print(case, result['sample_db']['100'])
