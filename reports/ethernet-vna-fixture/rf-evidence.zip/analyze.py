"""Calibrated differential response from independent measured incident bases.

Output is a PCB geometry comparison with ideal terminals, not a full connector
fixture certification. Raw traces, solver settings and CAD hashes are retained.
"""
from pathlib import Path
import argparse, json, hashlib
import numpy as np

O = Path(__file__).resolve().parent
METRICS = ('sdd11', 'sdd21', 'scd11', 'scd21', 'next_dd', 'fext_dd', 'next_cd', 'fext_cd',
           'load_dd21','load_cd21','load_next_dd','load_fext_dd','load_next_cd','load_fext_cd') + tuple(f'{kind}_{pair}' for pair in 'CD' for kind in ['next_dd','fext_dd','next_cd','fext_cd'])

def db(x):
    return 20*np.log10(np.maximum(abs(x), 1e-30))

def read_live(folder):
    raw = {'frequency_hz': np.arange(1,151)*1e6}
    for i in range(16):
        for kind in ['u','i']:
            rows=[]
            for line in (folder/f'port_{kind}t_{i+1}').read_text().splitlines():
                if not line or line.startswith('%'): continue
                try: row=[float(v) for v in line.split()]
                except ValueError: break
                if len(row)==2: rows.append(row)
            a=np.array(rows)
            raw[kind+'_time'+str(i)]=a[:,0]; raw[kind+str(i)]=a[:,1]
    return raw

def extract(odd, even, name, preview=False):
    folders=[O/'runs'/odd,O/'runs'/even]
    metas=[json.loads((p/'model.json').read_text(encoding='utf-8')) for p in folders]
    for key in ['case','input_sha256','pcb_sha256']:
        assert metas[0][key]==metas[1][key], key
    assert metas[0].get('material_model_version')==metas[1].get('material_model_version')
    assert metas[0].get('port_model_version')==metas[1].get('port_model_version')
    for key in ['pair','step','time_ns','margin','pml','pulse','pulse_ghz','mesh_style','edge_res']:
        assert metas[0]['args'].get(key)==metas[1]['args'].get(key), key
    for p,q in zip(metas[0]['ports'],metas[1]['ports']):
        assert all(p[k]==q[k] for k in ['number','net','start','stop','R'])
    assert [m['args']['mode'] for m in metas]==['odd','even']
    for key in 'xyz':
        assert np.array_equal(np.load(folders[0]/'grid.npz')[key], np.load(folders[1]/'grid.npz')[key])
    raws=[read_live(p) if preview else np.load(p/'results.npz') for p in folders]
    freq=raws[0]['frequency_hz']; assert np.array_equal(freq,raws[1]['frequency_hz'])
    idx=0 if metas[0]['args']['pair']=='A' else 2
    other=2-idx
    last=min(r[k][-1] for r in raws for k in r if '_time' in k)*1e9

    def waves(raw,end):
        aa=[]; bb=[]
        for i in range(16):
            fs=[]
            for kind in ['u','i']:
                t=raw[kind+'_time'+str(i)]; v=raw[kind+str(i)]
                use=t<=end*1e-9; t=t[use]; v=v[use]
                fs.append(2*(t[1]-t[0])*(np.exp(-2j*np.pi*freq[:,None]*t)@v))
            u,cur=fs
            aa.append((u+50*cur)/2); bb.append((u-50*cur)/2)
        return np.array(aa).T,np.array(bb).T

    def solve(end):
        pairs=[waves(r,end) for r in raws]
        A=np.stack([a[:,idx:idx+2] for a,b in pairs],axis=-1)
        B=np.stack([b for a,b in pairs],axis=-1)
        target=np.broadcast_to(np.array([1.,-1.])/np.sqrt(2),(len(freq),2))
        weights=np.linalg.solve(A,target[...,None])[...,0]
        outgoing=np.einsum('fij,fj->fi',B,weights)
        incident=np.einsum('fij,fj->fi',np.stack([a for a,b in pairs],axis=-1),weights)
        diff=lambda j:(outgoing[:,j]-outgoing[:,j+1])/np.sqrt(2)
        cm=lambda j:(outgoing[:,j]+outgoing[:,j+1])/np.sqrt(2)
        s=dict(sdd11=diff(idx),sdd21=diff(idx+8),scd11=cm(idx),scd21=cm(idx+8),
               next_dd=diff(other),fext_dd=diff(other+8),next_cd=cm(other),fext_cd=cm(other+8))
        for label,j in [('C',4),('D',6)]:
            s.update({f'next_dd_{label}':diff(j),f'fext_dd_{label}':diff(j+8),f'next_cd_{label}':cm(j),f'fext_cd_{label}':cm(j+8)})
        # A nonzero extracted incident residual at terminated ports must not be
        # hidden inside an assertion of a fully calibrated sixteen-port S matrix.
        # Also report actual loaded terminal voltages, normalized to incident A.
        total=outgoing+incident
        vd=lambda j:(total[:,j]-total[:,j+1])/np.sqrt(2)
        vc=lambda j:(total[:,j]+total[:,j+1])/np.sqrt(2)
        s.update(load_dd21=vd(idx+8),load_cd21=vc(idx+8),load_next_dd=vd(other),
                 load_fext_dd=vd(other+8),load_next_cd=vc(other),load_fext_cd=vc(other+8))
        non_driven=[i for i in range(16) if i not in [idx,idx+1]]
        diagnostics=dict(max_basis_condition_number=float(np.max(np.linalg.cond(A))),
            max_target_error=float(np.max(abs(incident[:,idx:idx+2]-target))),
            max_other_incident=float(np.max(abs(incident[:,non_driven]))),
            max_incident_on_other_pair=float(np.max(abs(incident[:,[other,other+1,other+8,other+9]]))),
            max_incident_output_common=float(np.max(abs((incident[:,idx+8]+incident[:,idx+9])/np.sqrt(2)))),
            max_incident_output_differential=float(np.max(abs((incident[:,idx+8]-incident[:,idx+9])/np.sqrt(2)))),
            min_outgoing_power=float(np.min(np.sum(abs(outgoing)**2,axis=1))),
            max_outgoing_power=float(np.max(np.sum(abs(outgoing)**2,axis=1))))
        phase_skew=-np.angle(-outgoing[:,idx+8]/outgoing[:,idx+9])/(2*np.pi*freq)*1e12
        amplitude_imbalance=db(outgoing[:,idx+8]/outgoing[:,idx+9])
        return s,diagnostics,outgoing,incident,phase_skew,amplitude_imbalance

    response,diag,outgoing,incident,phase,amplitude=solve(last)
    port_checks=[]
    for p in range(16):
        if p in [idx,idx+1]:continue
        denominator=incident[:,p]-outgoing[:,p]
        z=np.full(len(freq),np.nan+1j*np.nan,dtype=complex)
        np.divide(-50*(incident[:,p]+outgoing[:,p]),denominator,out=z,where=abs(denominator)>1e-30)
        strong=(abs(outgoing[:,p])>.01)&(freq>=1e7)
        port_checks.append(dict(port=p+1,impedance_at_100MHz=[float(z[99].real),float(z[99].imag)] if np.isfinite(z[99]) else None,
            strong_response=bool(np.any(strong)),
            max_abs_impedance_error_ohm_strong=float(np.max(abs(z[strong]-50))) if np.any(strong) else None))
    windows=[]; tail_arrays={}
    for ratio in [.7,.85,.95]:
        end=last*ratio
        s,d,*_=solve(end)
        windows.append(dict(end_ns=end,
            max_complex_delta={k:float(np.max(abs(s[k]-response[k]))) for k in METRICS},
            max_db_delta={k:float(np.max(abs(db(s[k])-db(response[k])))) for k in METRICS},
            db_delta_at_100MHz={k:float(abs(db(s[k])-db(response[k]))[99]) for k in METRICS},
            db_delta_at_150MHz={k:float(abs(db(s[k])-db(response[k]))[149]) for k in METRICS},
            max_db_delta_10_150MHz={k:float(np.max(abs(db(s[k])-db(response[k]))[freq>=1e7])) for k in METRICS}))
        if ratio==.95:
            tail_arrays={k+'_tail_complex_delta':s[k]-response[k] for k in METRICS}
    samples={str(f):{k:float(db(response[k])[f-1]) for k in METRICS} for f in [1,10,31,50,100,150]}
    for f in [1,10,31,50,100,150]:
        samples[str(f)].update(phase_imbalance_ps=float(phase[f-1]),amplitude_imbalance_db=float(amplitude[f-1]))
    report=dict(analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),name=name,case=metas[0]['case'],pair=metas[0]['args']['pair'],provisional=preview,
        material_model_version=metas[0].get('material_model_version','inherited-outer-gap-fill; disqualified for nominal-CAD ranking'),
        port_model_version=metas[0].get('port_model_version','overlapping-PEC-v2; mismatched passive THT loads'),
        passive_port_checks=port_checks,
        sources=[p.name for p in folders],pcb_sha256=metas[0]['pcb_sha256'],record_ns=last,
        settings=metas[0]['args'],diagnostics=diag,window_checks=windows,sample_db=samples,
        band_extrema_db={k:dict(min=float(np.min(db(response[k]))),max=float(np.max(db(response[k]))),
            max_at_MHz=float(freq[np.argmax(db(response[k]))]/1e6)) for k in METRICS},
        extraction='Measured driven-pair incident 2x2 matrix solve, unit differential incident wave; 100 ohm differential / 25 ohm common normalization. Nominal other-port loads are 50 ohm; inspect measured passive-port impedances and incident residuals. This is a terminated-network response, not a full 16x16 S-matrix extraction.',
        xy_grid_revision=metas[0]['xy_grid_revision'],
        raw_scope_wording_erratum='Raw builder scope retained inherited both-pairs/SHIELD wording; this common model has sixteen ports, four pairs and GND returns.',
        limitations=metas[0]['assumptions']+[metas[0]['scope'].replace('both pairs and all signal/SHIELD vias','all four pairs and all signal/GND vias'),
            'Sdd21 magnitude includes reflection, conversion, coupling and radiation, but excludes conductor and dielectric dissipation.',
            'load_* metrics use total terminal voltage divided by the driven differential incident-wave amplitude; these are loaded transfer ratios, not scattering coefficients.',
            'Output phase imbalance uses the two outgoing waves at the loaded output, not total terminal voltage, pure propagation delay or CAD centerline skew.'])
    target=O/('preview' if preview else 'combined');target.mkdir(exist_ok=True)
    np.savez(target/(name+'.npz'),frequency_hz=freq,**response,**tail_arrays,
        outgoing=outgoing,incident=incident,phase_imbalance_ps=phase,amplitude_imbalance_db=amplitude)
    (target/(name+'.json')).write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('odd');ap.add_argument('even');ap.add_argument('--name',required=True);ap.add_argument('--preview',action='store_true');a=ap.parse_args()
    r=extract(a.odd,a.even,a.name,a.preview)
    print(json.dumps({k:r[k] for k in ['name','provisional','record_ns','diagnostics','sample_db','window_checks']},indent=2))
