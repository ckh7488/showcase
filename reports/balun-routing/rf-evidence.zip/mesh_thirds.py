"""Resolve long horizontal trace edges symmetrically using openEMS thirds rule.

This changes the numerical grid, never the saved CAD polygons. Pad sampling
points may snap within their copper so they cannot distort a long trace edge.
"""
import numpy as np

def transverse_grid(model, background, critical, edge_res):
    features=sorted(set((float(t['start'][1]),float(t['width'])) for t in model['tracks']
        if abs(t['start'][1]-t['end'][1])<1e-8 and abs(t['start'][0]-t['end'][0])>8))
    mandatory=[];bands=[];protected=[]
    for center,width in features:
        inner=width/2-edge_res/3
        outer=width/2+2*edge_res/3
        # Identical node offsets on each same-width line, including its interior.
        n=max(2,int(np.ceil(2*inner/edge_res)))
        mandatory.extend(center+np.linspace(-inner,inner,n+1))
        mandatory.extend([center-outer,center+outer])
        bands.extend([(center-outer,center-inner),(center+inner,center+outer)])
        protected.append((center-outer-.04,center+outer+.04))
    chosen=list(np.unique(np.round(mandatory,8)))
    for v in list(critical)+list(background):
        if any(lo-1e-8<v<hi+1e-8 for lo,hi in protected):continue
        if chosen and np.min(abs(np.array(chosen)-v))<.0349:continue
        chosen.append(float(v))
    return np.unique(np.round(chosen,8)),features,bands

def audit_transverse(grid,features,bands):
    for lo,hi in bands:
        assert not np.any((grid>lo+1e-7)&(grid<hi-1e-7)), 'Smoothing split a thirds edge cell'
    result=[]
    for center,width in features:
        inside=grid[abs(grid-center)<width/2]
        result.append({'center_mm':center,'width_mm':width,'inside_offsets_mm':np.round(inside-center,8).tolist()})
    for p in result:
        for q in result:
            if abs(p['width_mm']-q['width_mm'])<1e-8:
                assert p['inside_offsets_mm']==q['inside_offsets_mm'], 'Unequal long-line transverse sampling'
    return result
