"""Eight-port openEMS CAD copper comparison. No transformer/connector-body model."""
from pathlib import Path
import os,ctypes,argparse,json,time,hashlib,sys
O=Path(__file__).resolve().parent
sys.path.insert(0,str(O))
# Install openEMS/CSXCAD for this Python environment first. On Windows, set
# OPENEMS_INSTALL_PATH to the directory containing the openEMS DLLs.
if os.name == 'nt' and os.environ.get('OPENEMS_INSTALL_PATH'):
 install=Path(os.environ['OPENEMS_INSTALL_PATH'])
 dh=os.add_dll_directory(str(install));dll=ctypes.WinDLL(str(install/'CSXCAD.dll'))
import numpy as np
from CSXCAD import ContinuousStructure
from openEMS import openEMS

ap=argparse.ArgumentParser()
ap.add_argument('--case',default='215cabd');ap.add_argument('--pair',choices=['A','B'],default='A')
ap.add_argument('--step',type=float,default=.10);ap.add_argument('--time-ns',type=float,default=4)
ap.add_argument('--margin',type=float,default=5);ap.add_argument('--threads',type=int,default=8)
ap.add_argument('--name',required=True);ap.add_argument('--setup-only',action='store_true')
ap.add_argument('--pulse',choices=['gaussian','bipolar'],default='gaussian')
ap.add_argument('--mode',choices=['odd','even'],default='odd')
ap.add_argument('--pml',action='store_true')
ap.add_argument('--mesh-style',choices=['uniform','thirds'],default='uniform')
ap.add_argument('--edge-res',type=float,default=.06)
a=ap.parse_args();out=O/'runs'/a.name
if out.exists():raise SystemExit('Run exists: choose a new name to preserve evidence.')
out.mkdir(parents=True)
src=O/'input'/(a.case+'-model.json');d=json.loads(src.read_text(encoding='utf-8'))
F=openEMS(NrTS=1000000,MaxTime=a.time_ns*1e-9,EndCriteria=1e-12)
if a.pulse=='gaussian':F.SetGaussExcite(0,2e9)
else:F.SetCustomExcite('((t-1e-9)/2e-10)*exp(-((t-1e-9)/2e-10)^2)',2e9,7e9)
F.SetOverSampling(10)
F.SetBoundaryCond(['PML_8' if a.pml else 'MUR']*6)
C=ContinuousStructure();F.SetCSX(C);g=C.GetGrid();g.SetDeltaUnit(1e-3)
fr4=C.AddMaterial('NP155F_prepreg_nominal_lossless',epsilon=4.4)
core=C.AddMaterial('core_CAD_nominal_lossless',epsilon=4.36)
air=C.AddMaterial('air',epsilon=1)
metal=C.AddMetal('copper_PEC')
fr4.AddBox([0,0,0],[66,40,1.5862],priority=0)
core.AddBox([0,0,.2454],[66,40,1.3408],priority=1)
L={'F.Cu':(0,.035),'In1.Cu':(.2454,.2454),'In2.Cu':(1.3408,1.3408),'B.Cu':(1.5512,1.5862)}
# Fill clearances first, then give separate copper islands higher priority.
for layer,ps in d['copper'].items():
 z0,z1=L[layer]
 for i,p in enumerate(ps):
  metal.AddLinPoly(np.array(p['outer']).T.tolist(),2,z0,z1-z0,priority=20)
  for hole in p['holes']:
   (air if layer in ['F.Cu','B.Cu'] else core).AddLinPoly(np.array(hole).T.tolist(),2,z0,z1-z0,priority=21)
 # Small pad islands inside plane antipads must override that clearance.
 for pad in d['pads']:
  if not pad['npth'] and layer in pad['layers']:
   for p in pad['polygons']:metal.AddLinPoly(np.array(p['outer']).T.tolist(),2,z0,z1-z0,priority=22)
for pad in d['pads']:
 x,y=pad['xy'];dx,dy=pad['drill']
 if not dx:continue
 if abs(dx-dy)>1e-6:raise RuntimeError('Slotted drill requires explicit geometry')
 if pad['npth']:air.AddCylinder([x,y,-.001],[x,y,1.587],dx/2,priority=30)
 else:metal.AddCylinder([x,y,0],[x,y,1.5862],dx/2+.025,priority=31)
for v in d['vias']:
 x,y=v['xy']
 metal.AddCylinder([x,y,0],[x,y,1.5862],v['drill']/2+.025,priority=31)
 for z0,z1 in L.values():
  theta=np.linspace(0,2*np.pi,49)
  metal.AddLinPoly(np.array([x+v['diameter']/2*np.cos(theta),y+v['diameter']/2*np.sin(theta)]).tolist(),2,z0,z1-z0,priority=22)

all_cases=[json.loads(p.read_text(encoding='utf-8')) for p in (O/'input').glob('*-model.json')]
thirds_features=[];thirds_bands=[]
for axis,lo,hi,end in [('x',15.,49.,66.),('y',14.,26.,40.)]:
 dense=np.arange(lo,hi+a.step/2,a.step)
 dim=0 if axis=='x' else 1
 anchors=sorted(set(round(v['xy'][dim],6) for case in all_cases for v in case['vias']))
 # Common grid across revisions, with every actual return barrel resolved.
 local=[c+off for c in anchors if c<lo or c>hi for off in [-.2,-.1,0,.1,.2]]
 critical=[]
 for case in all_cases:
  for pad in case['pads']:
   if pad['net'].startswith('/PAIR_'):
    critical.append(pad['xy'][dim])
    if axis=='x' and pad['ref']=='J1':critical.extend([pad['xy'][0]+.55,pad['xy'][0]+1.05])
 critical=np.unique(np.round(critical,8))
 if axis=='y' and a.mesh_style=='thirds':
  from mesh_thirds import transverse_grid
  dense,thirds_features,thirds_bands=transverse_grid(d,dense,critical,a.edge_res)
  critical=[]
 else:dense=np.array([v for v in dense if np.min(abs(critical-v))>=.0349])
 g.AddLine(axis,np.unique(np.round(np.r_[-a.margin,0,dense,local,critical,end,end+a.margin],8)))
 g.SmoothMeshLines(axis,.65,1.35)
z=np.r_[-a.margin,-1,-.3,0,.035,np.linspace(.035,.2454,5),.5,.8,1.1,np.linspace(1.3408,1.5512,5),1.5862,1.8862,2.5862,1.5862+a.margin]
g.AddLine('z',np.unique(z));g.SmoothMeshLines('z',.65,1.35)
grid={axis:np.array(g.GetLines(axis)) for axis in 'xyz'}
thirds_audit=[]
if a.mesh_style=='thirds':
 from mesh_thirds import audit_transverse
 thirds_audit=audit_transverse(grid['y'],thirds_features,thirds_bands)
if a.pml:
 for axis,extent in [('x',66.),('y',40.),('z',1.5862)]:
  assert grid[axis][8]<-1 and grid[axis][-9]>extent+1, 'Keep PCB outside PML cells: '+axis
via_samples=[]
for v in d['vias']:
 dx=float(np.min(abs(grid['x']-v['xy'][0])));dy=float(np.min(abs(grid['y']-v['xy'][1])))
 r=v['drill']/2+.025
 assert np.hypot(dx,dy)<r*.9, 'Barrel not safely sampled: '+str(v)
 via_samples.append({'net':v['net'],'xy':v['xy'],'nearest_vertical_edge_distance_mm':float(np.hypot(dx,dy)),'barrel_outer_radius_mm':r})
snap=lambda value,axis:float(grid[axis][np.argmin(abs(grid[axis]-value))])
ports=[];pm=[]
# Same ideal 50-ohm single-ended terminations at both connectors, both pairs.
# RJ45 ports cross the L2 pad antipad; SMD ports go from L2 to the top pad.
for ref in ['J1','J2']:
 for pair in ['A','B']:
  for sign in ['P','N']:
   net='/PAIR_'+pair+'_'+sign
   pad=next(p for p in d['pads'] if p['ref']==ref and p['net']==net)
   x,y=pad['xy'];y=snap(y,'y')
   if ref=='J1':
    start=[snap(x+1.05,'x'),y,.2454];stop=[snap(x+.55,'x'),y,.2454];direction='x'
   else:
    start=[snap(x,'x'),y,.2454];stop=[snap(x,'x'),y,.035];direction='z'
   excite=(1 if sign=='P' or a.mode=='even' else -1) if ref=='J1' and pair==a.pair else 0
   ports.append(F.AddLumpedPort(len(ports)+1,50,start,stop,direction,excite=excite,priority=40))
   pm.append({'number':len(ports),'ref':ref,'net':net,'start':start,'stop':stop,'direction':direction,'excite':excite,'R':50})
meta={'case':a.case,'sha':d['sha'],'args':vars(a),'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'pcb_sha256':d['pcb_sha256'],'grid':{k:len(v) for k,v in grid.items()},'cells':int(np.prod([len(v) for v in grid.values()])),'min_spacing_mm':{k:float(np.min(np.diff(v))) for k,v in grid.items()},'ports':pm,'scope':'Actual saved CAD trace/pad/filled-plane polygons, both pairs and all signal/SHIELD vias; connector bodies, cables and balun magnetics excluded. Ports are ideal 50-ohm single-ended PCB terminals.','assumptions':['Nominal CAD Dk 4.4 prepreg and 4.36 core; dielectric loss and soldermask omitted for routing comparison','PEC outer copper at 35um; inner reference copper represented by zero-thickness sheets at outer faces','PTH/via barrels use PEC-filled bores of external plated-barrel radius; plating 25um assumed','Board outline 66x40mm; finite reference planes and all saved return vias included','MUR boundary unless PML explicitly selected; convergence reported separately'],'source_geometry':{'signal_vias':sum(v['net'].startswith('/PAIR_') for v in d['vias']),'shield_vias':sum(v['net']=='/SHIELD' for v in d['vias'])}}
meta['via_grid_audit']=via_samples
meta['long_trace_grid_audit']=thirds_audit
(out/'model.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
C.Write2XML(str(out/'geometry.xml'));np.savez(out/'grid.npz',**grid)
F.Write2XML(str(out/'solver.xml'))
print('MODEL',json.dumps(meta,ensure_ascii=True),flush=True)
if a.setup_only:raise SystemExit(0)
t=time.perf_counter();F.Run(str(out),cleanup=False,numThreads=a.threads,verbose=0,dump_statistics=True);meta['wall_seconds']=time.perf_counter()-t
freq=np.arange(1,151,dtype=float)*1e6
for p in ports:p.CalcPort(str(out),freq,ref_impedance=50)
arr={'frequency_hz':freq}
for i,p in enumerate(ports):
 arr['u_time'+str(i)]=p.u_time;arr['i_time'+str(i)]=p.i_time;arr['u'+str(i)]=p.ut_tot;arr['i'+str(i)]=p.it_tot
np.savez(out/'results.npz',**arr)
meta['results_kind']='Raw terminal voltage/current samples and timestamps only. Use combine.py with both odd and even source states to recover mixed-mode S-parameters.'
(out/'model.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print('RESULT',json.dumps(meta,ensure_ascii=True),flush=True)
