"""Read live JSON snapshots safely while legacy writers replace their content."""
from pathlib import Path
import json,time
def read_json(path):
 for attempt in range(12):
  try:return json.loads(Path(path).read_text(encoding='utf-8-sig'))
  except (json.JSONDecodeError,OSError):
   if attempt==11:raise
   time.sleep(.05*(attempt+1))
def write_json(path,value):
 path=Path(path);temporary=path.with_suffix(path.suffix+'.new')
 temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
 for attempt in range(12):
  try:temporary.replace(path);return
  except PermissionError:
   if attempt==11:raise
   time.sleep(.05*(attempt+1))
