"""Combine only finished, matching two-source runs; retain all raw evidence."""
from pathlib import Path
import json,subprocess,sys,argparse
from retry_io import read_json
O=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--force',action='store_true');options=parser.parse_args()
groups={}
for folder in (O/'runs').iterdir():
 if not (folder/'results.npz').exists():continue
 m=read_json(folder/'model.json');a=m['args']
 if 'wall_seconds' not in m:continue
 key=(m['case'],a['pair'],a['step'],a['time_ns'],a['margin'],a['pml'],a['pulse'],a.get('mesh_style','uniform'),a.get('edge_res',.06))
 groups.setdefault(key,{})[a.get('mode','odd')]=folder.name
for key,pair in sorted(groups.items()):
 if set(pair)!= {'odd','even'}:continue
 case,letter,step,time_ns,margin,pml,pulse,mesh_style,edge_res=key
 name=f'{case}-{letter}-g{step:g}-t{time_ns:g}-m{margin:g}-'+('pml' if pml else 'mur')+'-'+pulse
 if mesh_style!='uniform':name+=f'-{mesh_style}-e{edge_res:g}'
 path=O/'combined'/f'{name}.json'
 if options.force or not path.exists() or json.loads(path.read_text(encoding='utf-8')).get('extraction_version',0)<2 or json.loads(path.read_text(encoding='utf-8')).get('diagnostic_version',0)<4:
  cp=subprocess.run([sys.executable,str(O/'combine.py'),pair['odd'],pair['even'],'--name',name],capture_output=True,text=True)
  if cp.returncode:print(cp.stdout,cp.stderr);raise SystemExit(cp.returncode)
 d=json.loads(path.read_text(encoding='utf-8'))
 print(name,'100MHz:',json.dumps({k:round(v,3) for k,v in d['sample_db']['100'].items()}),'power',round(d['diagnostics']['max_outgoing_power'],6),'tail95dB',json.dumps({k:round(v,4) for k,v in d['window_checks'][-1]['max_db_delta'].items()}))
