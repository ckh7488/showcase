"""Compare completed corrected-grid results; observations, not uncertainty bounds."""
from pathlib import Path
import itertools,json
import numpy as np

O=Path(__file__).resolve().parent
CASES=['8826733','acf8225','215cabd']
METRICS=['sdd11','scd21','sdd21']
records={}
for p in (O/'combined').glob('*.json'):
 d=json.loads(p.read_text(encoding='utf-8'));s=d['settings']
 if d['provisional'] or s.get('mesh_style')!='thirds' or s['pml'] or s['margin']!=5:continue
 if (s['step'],s['edge_res']) not in [(.075,.045),(.1,.06)]:continue
 key=(d['case'],d['pair'],s['step'])
 if key not in records or d['record_ns']>records[key]['record_ns']:records[key]=d

def values(case,pair,step,metric):
 d=records[(case,pair,step)]
 with np.load(O/'combined'/(d['name']+'.npz')) as raw:
  z=raw[metric]
  return (-1 if metric=='sdd21' else 1)*20*np.log10(abs(z))

def spans(mask):
 out=[]
 for i in np.flatnonzero(mask)+1:
  if out and out[-1][1]+1==i:out[-1][1]=int(i)
  else:out.append([int(i),int(i)])
 return out

out={'complete_grid_pairs':[],
 'interpretation':'Two-grid agreement and separation are observed numerical comparisons, not statistical confidence limits or manufacturing tolerances.',
 'at_100MHz':{},'comparisons':{},'numerical_checks':{}}
for pair in ['A','B']:
 available=[c for c in CASES if all((c,pair,g) in records for g in [.075,.1])]
 out['at_100MHz'][pair]={};out['comparisons'][pair]={}
 for c in available:
  key=c+'-'+pair;out['complete_grid_pairs'].append(key)
  main=records[(c,pair,.075)]
  base=records[(c,pair,.1)]
  row={}
  for m in METRICS:
   fine,coarse=[values(c,pair,g,m) for g in [.075,.1]]
   row[m]={'fine':float(fine[99]),'base':float(coarse[99]),'change':float(abs(fine[99]-coarse[99])),
     'fine_band_min':float(min(fine)),'fine_band_max':float(max(fine)),
     'grid_max_change':float(max(abs(fine-coarse)))}
  out['at_100MHz'][pair][c]=row
  out['numerical_checks'][key]={'diagnostics':main['diagnostics'],'last5percent_window':main['window_checks'][-1]}
 for first,second in itertools.combinations(available,2):
  result={}
  for m in METRICS:
   a=np.stack([values(first,pair,g,m) for g in [.075,.1]])
   b=np.stack([values(second,pair,g,m) for g in [.075,.1]])
   change=a-b # Positive: second case has the smaller reflected/converted/lost component.
   separation=a.min(axis=0)-b.max(axis=0)
   reverse=b.min(axis=0)-a.max(axis=0)
   result[m]={'second_improvement_at100_fine_db':float(change[0,99]),
    'second_improvement_at100_base_db':float(change[1,99]),
    'both_grids_favor_second_MHz':spans(np.all(change>0,axis=0)),
    'both_grids_favor_first_MHz':spans(np.all(change<0,axis=0)),
    'two_grid_value_ranges_separated_second_better_MHz':spans(separation>0),
    'two_grid_value_ranges_separated_first_better_MHz':spans(reverse>0),
    'minimum_two_grid_separation_for_second_db':float(min(separation))}
  out['comparisons'][pair][first+'__'+second]=result

(O/'results-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print('Completed main/comparison pairs:',len(out['complete_grid_pairs']),'/ 6')
for pair,rows in out['at_100MHz'].items():
 for c,row in rows.items():
  print(pair,c,' '.join(f'{m} {v["fine"]:.5f} (grid delta {v["change"]:.4f})' for m,v in row.items()))
