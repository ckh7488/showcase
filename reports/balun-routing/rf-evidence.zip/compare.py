"""Report observed grid/boundary differences without equating them to error bars."""
from pathlib import Path
import argparse,json,numpy as np
O=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('first');ap.add_argument('second');ap.add_argument('--name',required=True);a=ap.parse_args()
rows=[json.loads((O/'combined'/f'{v}.json').read_text(encoding='utf-8')) for v in [a.first,a.second]]
assert rows[0]['case']==rows[1]['case'] and rows[0]['pair']==rows[1]['pair']
data=[np.load(O/'combined'/f'{v}.npz') for v in [a.first,a.second]]
f=data[0]['frequency_hz'];assert np.array_equal(f,data[1]['frequency_hz'])
out={'sources':[a.first,a.second],'case':rows[0]['case'],'pair':rows[0]['pair'],'settings':[r['settings'] for r in rows],'metrics':{}}
for k in ['sdd11','scd21','sdd21']:
 x,y=[d[k] for d in data];diff=abs(x-y);dbdiff=abs(20*np.log10(abs(x))-20*np.log10(abs(y)))
 out['metrics'][k]={'max_complex_delta':float(max(diff)),'max_db_delta_1_150MHz':float(max(dbdiff)),'max_db_delta_10_150MHz':float(max(dbdiff[f>=1e7])),'db_delta_at_100MHz':float(dbdiff[99]),'worst_db_frequency_MHz':int(f[np.argmax(dbdiff)]/1e6)}
target=O/'comparisons';target.mkdir(exist_ok=True);(target/f'{a.name}.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
