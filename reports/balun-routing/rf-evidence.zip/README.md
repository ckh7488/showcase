# Three-revision Molex PCB routing comparison

Use the mixed-mode results in `combined/`. The package contains the actual saved
PCB copper models, CSXCAD geometry XMLs, port time traces, grid coordinates and
post-processing needed to inspect the report's numbers.

## What was calculated

The native `.kicad_pcb` files are included in `input/` and checked against the
SHA256 hashes retained in each exported model. They are the immutable source
revisions used for this comparison, not the current mutable repository checkout.

- Immutable CAD revisions: `8826733`, `acf8225`, `215cabd` from
  https://github.com/ckh7488/balun_test
- J1 RJ45 PCB terminals to J2 Molex PCB terminals, both signal pairs present.
- Saved pads, tracks, filled reference planes and all signal/SHIELD vias.
- 50-ohm single-ended terminations; normalized differential100ohm/common25ohm.
- Terminals are referenced to the adjacent L2 SHIELD plane. The actual J2 pin5
  remains unconnected; it is not repurposed as a ground terminal. This is the
  declared PCB-terminal scattering model, not a model of the external fixture's
  common-mode termination or the connector body's return path.
- 1–150 MHz, 1 MHz sampling interval. These are Fourier evaluations of the
  simulated impulse responses, not independent steady-state runs at each point.
- Main and comparison mesh settings, time-window checks and the separate boundary
  check are recorded in `selection.json` and each combined result's JSON.

Material values are nominal CAD values. Conductors are PEC, dielectric loss and
soldermask are omitted. Outer copper is35um and inner planes are sheets. Plated
barrels use a solid external-radius approximation. Connector bodies, cables,
transformers, fabrication variation and external noise are outside this model.
Consequently the insertion-loss curve is not the manufactured channel's total
attenuation, and this is not an Ethernet certification or a link-error-rate test.

## Recalculate the mixed-mode quantities

Install Python3 and NumPy, then run:

```sh
python collect.py --force
```

For an individual pair, use the two source-run names from its combined JSON:

```sh
python combine.py ODD_RUN EVEN_RUN --name CHECK_NAME
```

The two excitations are independent source states. Equal excitation-field
amplitudes do not ensure exactly balanced incident waves. `combine.py` extracts
the measured incident and reflected waves at each terminal, solves the2×2 incident
basis, and applies a unit differential incident vector. It does not subtract a DC
offset, fit a replacement curve or reuse results from a different CAD.

The `runs/*/results.npz` files in this package deliberately contain the raw
voltage/current samples and timestamps only. Preliminary individual-source ratios
are excluded because they are not mixed-mode S-parameters. Sample values are
unchanged. Full8-terminal probe traces are retained for independent processing.

## Re-run the electromagnetic model

Install compatible openEMS/CSXCAD Python bindings and NumPy. The calculation used
openEMS`v0.0.36-162-gdd75c17` and CSXCAD`v0.7.0-rc1` onWindows64bit. OnWindows, set
`OPENEMS_INSTALL_PATH` to the installed DLL directory before invoking`run.py`.
The bundled builder changes only the machine-specific DLL bootstrap; original
CSXCAD geometry XMLs are also included for every run.

```sh
python run.py --case 215cabd --pair A --mode odd --step .1 --mesh-style thirds --edge-res .06 --time-ns 3 --name NEW_A_ODD
python run.py --case 215cabd --pair A --mode even --step .1 --mesh-style thirds --edge-res .06 --time-ns 3 --name NEW_A_EVEN
python combine.py NEW_A_ODD NEW_A_EVEN --name NEW_A
```

Use each original`model.json` for its exact arguments. Never overwrite an existing
run folder. `input/*-model.json` contains already prepared polygons;`prepare.py`
can rebuild them from the companion native-export JSON using Shapely.

## Interpreting validation

Window and mesh changes are observed numerical sensitivities, not statistical
confidence intervals. Read complex-amplitude changes alongside dB changes when
a response is small. All final curves remain the directly extracted solver
results. Source hashes, terminal locations and material assumptions are retained.

Not every response met the numerical review targets. In particular, revision
`8826733` pair B Scd21 changes by about 12.1 dB between grids and 2.0 dB when the
last 5% of the main-grid record is excluded, at 100 MHz. Its absolute conversion
value is not numerically converged; sensitivity is greater at low frequencies.
The report marks target exceedances with a dagger while preserving the raw values.

Long horizontal traces use identical transverse node offsets for equal widths,
with one-third-inside/two-thirds-outside edge cells. `mesh_thirds.py` asserts that
grid smoothing preserves those cells. Pad-center anchors may be snapped within
the pad where they conflict with this rule. The saved port coordinates are the
actual coordinates used. Earlier uniform-grid trials changed the representation
of equal-width conductors unequally and must not be mixed into accepted rankings.

Mesh reference: https://wiki.openems.de/index.php/Tutorial:_Microstrip_Notch_Filter.html

Definitions: https://helpfiles.keysight.com/csg/e5080b/S1_Settings/Balanced_Measurements.htm

Port API: https://docs.openems.de/python/openEMS/ports.html
