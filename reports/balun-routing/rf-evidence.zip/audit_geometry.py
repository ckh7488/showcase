from pathlib import Path
import json
from shapely.geometry import Polygon,Point
O=Path(__file__).resolve().parent
reports=[]
for f in sorted((O/'input').glob('*-model.json')):
 d=json.loads(f.read_text(encoding='utf-8'))
 ls={l:[Polygon(p['outer'],p['holes']) for p in ps] for l,ps in d['copper'].items()}
 def comp(layer,point):
  ids=[i for i,poly in enumerate(ls[layer]) if poly.buffer(1e-8).covers(Point(point))]
  assert len(ids)==1,(d['id'],layer,point,ids)
  return layer,ids[0]
 parent={}
 def find(k):
  parent.setdefault(k,k)
  if parent[k]!=k:parent[k]=find(parent[k])
  return parent[k]
 def join(a,b):parent[find(a)]=find(b)
 for p in d['pads']:
  if p['npth'] or not p['drill'][0]:continue
  ids=[comp(l,p['xy']) for l in p['layers']]
  for x,y in zip(ids,ids[1:]):join(x,y)
 for v in d['vias']:
  ids=[comp(l,v['xy']) for l in ls]
  for x,y in zip(ids,ids[1:]):join(x,y)
 nets={}
 for p in d['pads']:
  if p['net'].startswith('/PAIR_') or p['net']=='/SHIELD':
   net=p['net'];node=find(comp(p['layers'][0],p['xy']))
   nets.setdefault(net,set()).add(node)
 assert all(len(s)==1 for s in nets.values()),(d['id'],'disconnected',nets)
 assert len({next(iter(s)) for s in nets.values()})==len(nets),(d['id'],'short')
 report={'case':d['id'],'connected_signal_nets':sorted(n for n in nets if n.startswith('/PAIR_')),'shield_isolated_from_signal':True,'vias':len(d['vias']),'ports':[]}
 shield=max(ls['In1.Cu'],key=lambda p:p.area)
 for pad in d['pads']:
  if pad['ref']=='J1' and pad['net'].startswith('/PAIR_'):
   x,y=pad['xy'];start=[x+1.05,y];stop=[x+.55,y]
   assert shield.covers(Point(start)),('reference terminal misses SHIELD',start)
   assert not shield.covers(Point(stop)),('signal terminal shorts SHIELD',stop)
   assert comp('In1.Cu',stop)==comp('In1.Cu',pad['xy'])
   report['ports'].append({'net':pad['net'],'reference_on_shield':True,'signal_on_pad':True})
 reports.append(report)
(O/'geometry-audit.json').write_text(json.dumps(reports,indent=2),encoding='utf-8')
print(json.dumps(reports,indent=2))
