"""Prepare copper polygons from saved KiCad geometry, without changing the CAD."""
from pathlib import Path
import json
from shapely.geometry import Polygon,LineString,Point
from shapely.ops import unary_union
O=Path(__file__).resolve().parent
for source in sorted((O/'input').glob('???????.json')):
 d=json.loads(source.read_text(encoding='utf-8')); ls={l:[] for l in ['F.Cu','In1.Cu','In2.Cu','B.Cu']}
 def poly(p):return Polygon(p['outer'],p['holes']).buffer(0)
 for z in d['zones']:
  ls[z['layer']].extend(poly(p) for p in z['polygons'])
 for t in d['tracks']:
  ls[t['layer']].append(LineString([t['start'],t['end']]).buffer(t['width']/2,quad_segs=8))
 for p in d['pads']:
  if p['npth']:continue
  for l in p['layers']:ls[l].extend(poly(q) for q in p['polygons'])
 for v in d['vias']:
  for l in ls:ls[l].append(Point(v['xy']).buffer(v['diameter']/2,quad_segs=16))
 def serialize(g):
  ps=[g] if g.geom_type=='Polygon' else list(g.geoms)
  return [{'outer':list(p.exterior.coords),'holes':[list(h.coords) for h in p.interiors]} for p in ps if p.geom_type=='Polygon']
 d['copper']={l:serialize(unary_union(ps).buffer(0)) for l,ps in ls.items()}
 d['copper_areas_mm2']={l:sum(Polygon(p['outer'],p['holes']).area for p in ps) for l,ps in d['copper'].items()}
 (O/'input'/(d['id']+'-model.json')).write_text(json.dumps(d,ensure_ascii=False),encoding='utf-8')
 print(d['id'],d['copper_areas_mm2'], 'shield vias',sum(v['net']=='/SHIELD' for v in d['vias']))
