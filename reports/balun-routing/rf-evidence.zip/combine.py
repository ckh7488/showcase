"""Recover mixed-mode scattering from two independent measured incident bases.

The excitation field amplitudes do not imply equal incident power waves. Solve
B = S A at each frequency, then apply a unit differential incident vector.
"""
from pathlib import Path
import argparse,json
import numpy as np
O=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('odd');ap.add_argument('even');ap.add_argument('--name',required=True);ap.add_argument('--preview',action='store_true');args=ap.parse_args()
folders=[O/'runs'/args.odd,O/'runs'/args.even]
metas=[json.loads((p/'model.json').read_text(encoding='utf-8')) for p in folders]
def read_live(folder):
 raw={'frequency_hz':np.arange(1,151)*1e6}
 for i in range(8):
  for kind in ['u','i']:
   rows=[]
   for line in (folder/f'port_{kind}t_{i+1}').read_text().splitlines():
    if not line or line.startswith('%'):continue
    try:row=[float(v) for v in line.split()]
    except ValueError:break
    if len(row)==2:rows.append(row)
   a=np.array(rows);raw[kind+'_time'+str(i)]=a[:,0];raw[kind+str(i)]=a[:,1]
 return raw
raws=[read_live(p) if args.preview else np.load(p/'results.npz') for p in folders]
assert metas[0]['case']==metas[1]['case']
assert metas[0]['args']['pair']==metas[1]['args']['pair']
assert metas[0]['input_sha256']==metas[1]['input_sha256']
for key in ['step','time_ns','margin','pml','pulse','mesh_style','edge_res']:
 assert metas[0]['args'].get(key)==metas[1]['args'].get(key), 'Source states must use identical model settings'
for p,q in zip(metas[0]['ports'],metas[1]['ports']):
 assert all(p[k]==q[k] for k in ['number','net','start','stop','R'])
for key in ['x','y','z']:
 assert np.array_equal(np.load(folders[0]/'grid.npz')[key],np.load(folders[1]/'grid.npz')[key])
freq=raws[0]['frequency_hz'];assert np.array_equal(freq,raws[1]['frequency_hz'])
idx=0 if metas[0]['args']['pair']=='A' else 2
def waves(raw,end=None):
 aa=[];bb=[]
 for i in range(8):
  fs=[]
  for kind in ['u','i']:
   t=raw[kind+'_time'+str(i)];v=raw[kind+str(i)]
   if end is not None:
    use=t<=end*1e-9;t=t[use];v=v[use]
   fs.append(2*(t[1]-t[0])*(np.exp(-2j*np.pi*freq[:,None]*t)@v))
  u,cur=fs;aa.append((u+50*cur)/2);bb.append((u-50*cur)/2)
 return np.array(aa).T,np.array(bb).T
def solve(end=None):
 pairs=[waves(r,end) for r in raws]
 A=np.stack([a[:,idx:idx+2] for a,b in pairs],axis=-1)
 B=np.stack([b for a,b in pairs],axis=-1)
 target=np.broadcast_to(np.array([1.,-1.])/np.sqrt(2),(len(freq),2))
 weights=np.linalg.solve(A,target[...,None])[...,0]
 outgoing=np.einsum('fij,fj->fi',B,weights)
 all_incident=np.einsum('fij,fj->fi',np.stack([a for a,b in pairs],axis=-1),weights)
 s={'sdd11':(outgoing[:,idx]-outgoing[:,idx+1])/np.sqrt(2),'sdd21':(outgoing[:,idx+4]-outgoing[:,idx+5])/np.sqrt(2),'scd21':(outgoing[:,idx+4]+outgoing[:,idx+5])/np.sqrt(2)}
 diagnostics={'max_basis_condition_number':float(np.max(np.linalg.cond(A))),'max_target_error':float(np.max(abs(all_incident[:,idx:idx+2]-target))),'max_other_incident':float(np.max(abs(all_incident[:,[i for i in range(8) if i not in [idx,idx+1]]]))),'max_outgoing_power':float(np.max(np.sum(abs(outgoing)**2,axis=1)))}
 return s,diagnostics
last=min(r[k][-1] for r in raws for k in r if '_time' in k)*1e9
results,diagnostics=solve(last if args.preview else None)
cuts=[];time_deltas={k:np.zeros(len(freq)) for k in results}
def db(x):return 20*np.log10(np.maximum(abs(x),1e-20))
for cut in [last*.7,last*.85,last*.95]:
 s,d=solve(cut)
 for k in results:time_deltas[k]=np.maximum(time_deltas[k],abs(s[k]-results[k]))
 cuts.append({'end_ns':cut,'max_complex_delta':{k:float(np.max(abs(v-results[k]))) for k,v in s.items()},'max_db_delta':{k:float(np.max(abs(db(v)-db(results[k])))) for k,v in s.items()}})
 cuts[-1]['max_db_delta_10_150MHz']={k:float(np.max(abs(db(v)-db(results[k]))[freq>=1e7])) for k,v in s.items()}
 cuts[-1]['db_delta_at_100MHz']={k:float(abs(db(v)-db(results[k]))[99]) for k,v in s.items()}
 cuts[-1]['worst_db_frequency_MHz']={k:int(freq[np.argmax(abs(db(v)-db(results[k])))]/1e6) for k,v in s.items()}
fit=np.column_stack([np.ones(20),1j*freq[:20]/1e8,(freq[:20]/1e8)**2])
intercept=np.linalg.lstsq(fit,results['scd21'][:20],rcond=None)[0][0]
summary={'name':args.name,'case':metas[0]['case'],'pair':metas[0]['args']['pair'],'sources':[p.name for p in folders],'record_ns':last,'settings':{k:metas[0]['args'][k] for k in ['step','margin','pulse','pml']},'diagnostics':diagnostics,'window_checks':cuts,'cm_dc_intercept_abs_diagnostic_only':float(abs(intercept)),'sample_db':{str(f):{k:float(db(v)[f-1]) for k,v in results.items()} for f in [1,10,31,50,100,150]},'extraction':'Two independent source states; measured single-ended A/B wave matrices solved at each frequency; 100ohm differential and25ohm common normalization. No DC subtraction or fitted curve replacement.'}
summary['provisional']=args.preview;summary['extraction_version']=2
summary['diagnostic_version']=4
summary['settings'].update({k:metas[0]['args'].get(k) for k in ['mesh_style','edge_res']})
target=O/('preview' if args.preview else 'combined');target.mkdir(exist_ok=True)
np.savez(target/(args.name+'.npz'),frequency_hz=freq,**results,
 **{k+'_time_delta_abs':v for k,v in time_deltas.items()},
 **{k+'_last5_db_delta':abs(db(s[k])-db(results[k])) for k in results})
(target/(args.name+'.json')).write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
